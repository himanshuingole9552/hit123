# how to read JSON file

from pandas import *

# myfile=read_json("myfile.json")
myfile=read_json("details.json")
mydataframe=DataFrame(myfile)
print(mydataframe)
