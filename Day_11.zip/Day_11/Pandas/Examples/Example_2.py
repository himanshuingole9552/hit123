# Series object is a one-dimensional labelled or indexed array

from pandas import *

first=Series([100,200,300,400,500])
print(first)
print("\n")
print(type(first))
