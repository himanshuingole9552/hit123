# pie chart

from matplotlib import pyplot as py

fruits=['Apple','Mango','Banana','Water_melon']
quantity=[30,50,15,5]

# inside "autopct" 0.1  means 1 decimal point

# py.pie(quantity,labels=fruits,autopct='%0.1f%%',colors=['red','blue','yellow','pink'])
py.pie(quantity,labels=fruits,colors=['red','blue','yellow','pink'])
py.legend()
py.show()