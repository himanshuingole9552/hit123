# violinplot

from matplotlib import pyplot as py

first=[1,2,3,4,5,6,7,8,9]
second=[1,2,3,4,5,4,3,2,1]
third=[6,7,8,9,8,7,6,5,4]

data=list([first,second,third])
# py.violinplot(data,showmedians=True)
py.violinplot(data)
py.show()