from os import path

print("File Exists\t",path.exists("d:\\my1.xml"))
print("Directory Exists\t",path.exists("d:\\docs"))

