import shutil

#  Python allows you to quickly create zip/tar archives.
# Following command will zip entire directory

shutil.make_archive("e:\\temp\\sample.zip","zip","e:\\temp1")
print("Done")

