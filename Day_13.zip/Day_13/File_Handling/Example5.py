# how to read from a file


with open("d:\\FileDemo.java","r") as f:
    data=f.read()
    print(data)

print("Done")


